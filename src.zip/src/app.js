import React from "react";
import ProductCard from "./components/ProductCard";
<ProductCard
  image="https://via.placeholder.com/200"
  name="Cool Sneakers"
  price={79.99}
  variants={["Red", "Blue", "Black"]}
  inStock={true}
  onAddToCart={() => alert("Added to cart!")}
/>

function App() {
  return (
    <div style={{ display: "flex", gap: "20px", flexWrap: "wrap" }}>
      <ProductCard
        image="https://via.placeholder.com/200"
        name="Cool Sneakers"
        price={79.99}
        variants={["Red", "Blue", "Black"]}
        inStock={true}
        onAddToCart={() => alert("Added to cart!")}
      />

      <ProductCard
        image="https://via.placeholder.com/200"
        name="Stylish Jacket"
        price={129.99}
        variants={["Small", "Medium", "Large"]}
        inStock={false}
      />
    </div>
  );
}

export default App;
