import React, { useState } from "react";
import "./ProductCard.css";

const ProductCard = ({
  image,
  name,
  price,
  variants = [],
  inStock = true,
  onAddToCart
}) => {
  const [selectedVariant, setSelectedVariant] = useState(variants[0] || "");
  const [imageLoading, setImageLoading] = useState(true);
  const [imageError, setImageError] = useState(false);

  const handleAddToCart = () => {
    if (inStock && onAddToCart) {
      onAddToCart({
        name,
        price,
        variant: selectedVariant,
        image
      });
    }
  };

  const handleImageLoad = () => {
    setImageLoading(false);
  };

  const handleImageError = () => {
    setImageLoading(false);
    setImageError(true);
  };

  return (
    <div className="product-card">
      {/* Stock Status Badge */}
      {!inStock && <div className="stock-badge">Out of Stock</div>}
      
      {/* Image Container */}
      <div className="product-image-container">
        {imageLoading && !imageError && (
          <div className="image-loading">
            <div className="loading-spinner"></div>
          </div>
        )}
        
        {imageError ? (
          <div className="image-error">
            <div className="error-icon">📷</div>
            <p>Image unavailable</p>
          </div>
        ) : (
          <img
            src={image}
            alt={name}
            className="product-image"
            onLoad={handleImageLoad}
            onError={handleImageError}
          />
        )}
      </div>

      {/* Content */}
      <div className="product-content">
        <h3 className="product-name">{name}</h3>
        
        <div className="price-container">
          <span className="product-price">
            ${typeof price === 'number' ? price.toFixed(2) : price}
          </span>
          {!inStock && <span className="unavailable-text">Unavailable</span>}
        </div>

        {/* Variants Dropdown */}
        {variants.length > 0 && (
          <div className="variant-container">
            <label className="variant-label">
              {typeof variants[0] === 'string' && variants[0].match(/^(xs|s|m|l|xl|xxl|small|medium|large)$/i) ? 'Size' : 'Option'}:
            </label>
            <select
              className="variant-select"
              value={selectedVariant}
              onChange={(e) => setSelectedVariant(e.target.value)}
              disabled={!inStock}
            >
              {variants.map((variant, idx) => (
                <option key={idx} value={variant}>
                  {variant}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Add to Cart Button */}
        <button
          className={`add-to-cart-btn ${!inStock ? 'disabled' : ''}`}
          disabled={!inStock}
          onClick={handleAddToCart}
        >
          {inStock ? (
            <>
              🛒 Add to Cart
            </>
          ) : (
            'Out of Stock'
          )}
        </button>
      </div>
    </div>
  );
};

export default ProductCard;